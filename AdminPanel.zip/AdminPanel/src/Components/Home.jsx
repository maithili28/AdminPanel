import React, { useState, useEffect } from 'react';
import Nav from '../Nav/Nav';

const DetailCard = ({ value, label, iconClass }) => (
  <div className="col-md-3 p-1">
    <div className="p-3 bg-white shadow-sm d-flex justify-content-around align-items-center rounded-2">
      <div>
        <h3 className="fs-2">{value}</h3>
        <p className="fs-5">{label}</p>
      </div>
      <i className={`bi ${iconClass} p-3 fs-1`}></i>
    </div>
  </div>
);

const Home = ({ Toggle }) => {
  const details = [
    { value: 230, label: 'products', iconClass: 'bi-cart-plus' },
    { value: 2450, label: 'sales', iconClass: 'bi-currency-dollar' },
    { value: 2250, label: 'delivery', iconClass: 'bi-truck' },
    { value: '20%', label: 'increase', iconClass: 'bi-graph-up-arrow' },
  ];

  const [orders, setOrders] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [newOrder, setNewOrder] = useState({
    title: '',
    brandname: '',
    price: '',
    description: ' ',
    featured:' ',
  });

  useEffect(() => {
    // Fetch orders 
    fetch('http://localhost/AdminPanel/src/fetchOrders.php')
      .then(response => response.json())
      .then(data => setOrders(data))
      .catch(error => console.error('Error fetching orders:', error));
  }, []);

  const handleAddNewOrder = () => {
    setShowForm(true);
  };

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setNewOrder({ ...newOrder, [name]: value });
  };

const handleFormSubmit = (e) => {
  e.preventDefault();
  fetch('http://localhost/AdminPanel/src/addOrder.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(newOrder)
  })
    .then(response => response.json())
    .then(data => {
      if (!data.error) {
        setOrders([...orders, data]);
        setShowForm(false);
        setNewOrder({
          title: '',
          brandname: '',
          price: '',
          description: ' ',
          featured:' '
        });
      } else {
        console.error(data.error);
      }
    })
    .catch(error => console.error('Error adding order:', error));
};



 const handleRemoveOrder = (id) => {
  fetch('http://localhost/AdminPanel/src/deleteOrder.php', {
    method: 'DELETE',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ id })
  })
    .then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    })
    .then(data => {
      if (data.success) {
        setOrders(orders.filter(order => order.id !== id));
      } else {
        console.error(data.error || 'Unknown error occurred');
      }
    })
    .catch(error => console.error('Error deleting order:', error));
};



  return (
    <div>
      <Nav Toggle={Toggle} />

      <div className='container-fluid'>
        <div className='row g-3 my-2'>
          {details.map((detail, index) => (
            <DetailCard
              key={index}
              value={detail.value}
              label={detail.label}
              iconClass={detail.iconClass}
            />
          ))}
        </div>
      </div>

      <div className="d-flex align-items-center justify-content-between mb-3">
        <h5 className="text-white">Recent orders</h5>
        <button className="btn btn-primary" onClick={handleAddNewOrder}>+ ADD</button>
      </div>
      {showForm && (
        <form onSubmit={handleFormSubmit} className="mb-3">
          <div className="mb-2">
            <label htmlFor="title" className="form-label">Title</label>
            <input
              type="text"
              className="form-control"
              id="title"
              name="title"
              value={newOrder.title}
              onChange={handleFormChange}
              required
            />
          </div>
          <div className="mb-2">
            <label htmlFor="brandname" className="form-label">Brand Name</label>
            <input
              type="text"
              className="form-control"
              id="brandname"
              name="brandname"
              value={newOrder.brandname}
              onChange={handleFormChange}
              required
            />
          </div>
          <div className="mb-2">
            <label htmlFor="price" className="form-label">Price</label>
            <input
              type="number"
              className="form-control"
              id="price"
              name="price"
              value={newOrder.price}
              onChange={handleFormChange}
              required
            />
          </div>
          
           
           <div className="mb-2">
            <label htmlFor="description" className="form-label">Description</label>
            <input
              type="text"
              className="form-control"
              id="description"
              name="description"
              value={newOrder.description}
              onChange={handleFormChange}
              required
            />
          </div>
         
           <div className="mb-2">
            <label htmlFor="featured" className="form-label">Featured</label>
            <input
              type="text"
              className="form-control"
              id="featured"
              name="featured"
              value={newOrder.featured}
              onChange={handleFormChange}
              required
            />
          </div>
          <button type="submit" className="btn btn-success">Submit</button>
        </form>
      )}
      <table className="table table-secondary table-striped">
        <thead>
          <tr>
            <th scope="col">ID</th>
            <th scope="col">Title</th>
            <th scope="col">Brand Name</th>
            <th scope="col">Price</th>
            <th scope="col">Description</th>
            <th scope="col">Featured</th>

            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
          {orders.map((order) => (
            <tr key={order.id}>
              <th scope="row">{order.id}</th>
              <td>{order.title}</td>
              <td>{order.brandname}</td>
              <td>{order.price}</td>
              <td>{order.description}</td>
              <td>{order.featured}</td>

              <td>
                <button
                  className="btn btn-danger"
                  onClick={() => handleRemoveOrder(order.id)}
                >
                  Remove
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Home;
