import React from 'react';
import '../Sidebar/style.css';


const SidebarItem = ({ iconClass, label, onClick }) => {
  return (
    <a className='list-group-item py-2' onClick={onClick} style={{ cursor: 'pointer' }}>
      <i className={`bi ${iconClass} fs-5 me-3`}></i>
      <span>{label}</span>
    </a>
  );
};


function Sidebar() {

  const handleItemClick = (label) => {
    switch (label) {
      case 'Dashboard':
        console.log('Dashboard clicked');
        break;
      case 'Home':
        console.log('Home clicked');
        break;
      case 'Products':
        console.log('Products clicked');
        break;
      case 'Report':
        console.log('Report clicked');
        break;
      default:
        console.log(`${label} clicked`);
    }
  };

  const items = [
    { iconClass: 'bi-speedometer2', label: 'Dashboard' },
    { iconClass: 'bi-house', label: 'Home' },
    { iconClass: 'bi-table', label: 'Products' },
    { iconClass: 'bi-clipboard-data', label: 'Report' },
    { iconClass: 'bi-people', label: 'Customers' },
    { iconClass: 'bi-power', label: 'Logout' },
  ];

    return (
      
    <div className='bg-white Sidebar p-2'>
      <div className='m-2'>
        <img src='/public/logo.png' alt='logo' />
        <span className='brand-name fs-10'>Shopping</span>
      </div>
      <hr className='text-dark' />
      <div className='list-group list-group-flush'>
        {items.map((item, index) => (
          <SidebarItem
            key={index}
            iconClass={item.iconClass}
            label={item.label}
            onClick={() => handleItemClick(item.label)}

          />
        ))}
      </div>
    </div>
  );
}

export default Sidebar;
