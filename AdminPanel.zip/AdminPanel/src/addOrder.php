<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "e-commerce";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    echo json_encode(["error" => "Connection failed: " . $conn->connect_error]);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);

$title = $data['title'];
$brandname = $data['brandname'];
$price = $data['price'];
$description = $data['description'];
$featured = $data['featured'];


$sql = "INSERT INTO product (title, brandname, price, description,featured) VALUES ('$title', '$brandname', '$price','$description','$featured')";

if ($conn->query($sql) === TRUE) {
    $newOrderId = $conn->insert_id;
    $newOrder = [
        'id' => $newOrderId,
        'title' => $title,
        'brandname' => $brandname,
        'price' => $price,
        'description'=>$description,
        'featured'=>$featured
    ];
    echo json_encode($newOrder);
} else {
    echo json_encode(["error" => "Error adding order: " . $conn->error]);
}

$conn->close();
?>
